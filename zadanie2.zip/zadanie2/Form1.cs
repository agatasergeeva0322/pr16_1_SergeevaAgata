﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace zadanie1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void НАЧАТЬ_Click(object sender, EventArgs e)
        {
            string[] array = textBox1.Text.Split(' ');
            //Проверка на наличие "/" в строке
            bool containSlash = array.Any(x => x.Contains("/"));
            if (containSlash == true)
            {
                //определение количества цифр в строке
                var digitCount = array.SelectMany(x => x).Count(char.IsDigit);
                label2.Text = $"Количество цифр в строке: {digitCount}";

                //Проверка на наличие файла для записи
                if (File.Exists("newarray.txt"))
                {
                    //Запись в файл
                    using (StreamWriter writer = new StreamWriter("newarray.txt"))
                    {
                        //вывод элементов массива до "/"
                        var elementBefSlash = array.TakeWhile(x => x != "/").ToList();
                        label3.Text = "Элементы массива до '/': ";
                        foreach (var element in elementBefSlash)
                        {
                            label3.Text += $"{element} ";
                            writer.Write($"{element} ");
                        }

                        //вывод элементов массива после "/" с изменением регистра на противоположный
                        var newRegister = array.SkipWhile(x => x != "/")
                                               .Select(x => string.Concat(x.Select(c => char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c))))
                                               .ToArray();
                        label4.Text = "Элементы массива после '/' с изменением регистра на противоположный: ";
                        foreach (var element in newRegister)
                        {
                            label4.Text += $"{element} ";
                            writer.Write($"{element} ");
                        }

                    }
                }
                else MessageBox.Show("Файл для записи нового массива не найден!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("В строке нет '/'!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }
    }
}
